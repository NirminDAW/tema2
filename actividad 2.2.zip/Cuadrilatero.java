package com.mycompany.cuadrilatero;
import java.util.Scanner;

public class Cuadrilatero {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Introduce la longitud del lado 1: ");
        double lado1 = input.nextDouble();

        System.out.print("Introduce la longitud del lado 2: ");
        double lado2 = input.nextDouble();

        if (lado1 == lado2) {
            System.out.println("Es un cuadrado.");
            double area = lado1 * lado2;
            double perimetro = lado1 * 4;
            System.out.println("Área: " + area);
            System.out.println("Perímetro: " + perimetro);
        } else {
            System.out.println("Es un rectángulo.");
            double area = lado1 * lado2;
            double perimetro = (lado1 * 2) + (lado2 * 2);
            System.out.println("Área: " + area);
            System.out.println("Perímetro: " + perimetro);
        }
    }
}
