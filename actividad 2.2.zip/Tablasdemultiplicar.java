package com.mycompany.tablasdemultiplicar;
import java.util.Scanner;

public class Tablasdemultiplicar {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese un número para mostrar su tabla de multiplicar: ");
        int num = sc.nextInt();
        if (num< 0){
            System.out.println("El numero no puede ser menor que 0");
        }
        if (num < 1 || num > 10) {
            System.out.println("Solo se pueden mostrar las tablas de multiplicar del 1 al 10.");
        } else {
            System.out.println("Tabla de multiplicar del " + num + ":");
            for (int i = 1; i <= 10; i++) {
                int resultado = num * i;
                System.out.println(num + " x " + i + " = " + resultado);
            }
        }
    }
}
