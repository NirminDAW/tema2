package com.mycompany.Dimensiones;
import java.util.Scanner;

public class Dimensiones {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double base, altura;

        do {
            System.out.print("Ingrese la base del rectángulo: ");
            base = scanner.nextDouble();

            System.out.print("Ingrese la altura del rectángulo: ");
            altura = scanner.nextDouble();
            if(altura < 0){
                System.out.println("La altura no puede ser menor que 0");
            }
        }while(altura < 0);
            if (base < 0) {
                System.out.println("La base no puede ser menor que 0");
            
        } while (base < 0);

        double area = base * altura;
        double perimetro = 2 * (base + altura);

        System.out.println("El área del rectángulo es: " + area);
        System.out.println("El perímetro del rectángulo es: " + perimetro);
    }
}

    
        
