package com.mycompany.leerdatos.java;
import java.util.Scanner;


public class LeerdatosJava {
    
    
    public static void main(String[] args) {
        
        Scanner console = new Scanner (System.in);
        
        System.out.println("Escribe un entero de 1 a 10 y luego pulsa la tecla enter");
        int  entero = console.nextInt();
        System.out.println("El entero que has escrito es el " +entero);
        
    }
}
         
        
        
          