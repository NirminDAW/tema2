package com.mycompany.volumencaja.java;
import java.util.Scanner;

public class Volumencaja {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double longitud, anchura, altura, volumen;

        do {
            System.out.print("Introduce la longitud de la caja: ");
            longitud = sc.nextDouble();
			if(longitud < 0){
				System.out.println("La longitud no puede ser menor que 0");
			}
        } while (longitud < 0);

        do {
            System.out.print("Introduce la anchura de la caja: ");
            anchura = sc.nextDouble();
			if(anchura < 0){
				System.out.println("La anchura no puede ser menor que 0");
			}
        } while (anchura < 0);

        do {
            System.out.print("Introduce la altura de la caja: ");
            altura = sc.nextDouble();
			if (altura < 0){
				System.out.println("La altura no puede ser menor que 0");
			}
        } while (altura < 0);

        volumen = longitud * anchura * altura;

        System.out.println("El volumen de la caja es: " + volumen);
    }
}
